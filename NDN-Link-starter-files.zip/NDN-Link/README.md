# NDN-Link: A Named Data Networking Testbed

NDN-Link is a Named Data Networking (NDN) testbed that demonstrates content-centric networking. Instead of requesting content by IP address, users request content by **name**. Any node that has cached the content can serve it, making the system serverless, resilient, and secure.

## Main Features
- **Name-Based Resolution:** Request content using NDN names (e.g., `/college/cn/teamA/files/report.pdf`).
- **In-Network Caching:** Content is cached at multiple nodes and served from the nearest available node.
- **Serverless Delivery:** Content is available even if the original producer goes offline.
- **Data-Centric Security:** Every Data packet is hashed (SHA-256) and signed to prevent tampering.
- **Interest Aggregation:** Multiple requests for the same content are combined.

## Core NDN Concepts Implemented
- **Packets:** Actual NDN Interest and Data packet structures.
- **Naming:** Hierarchical content addressing.
- **CS / PIT / FIB:** The three tables that drive NDN forwarding.
- **Tamper Test:** Demonstrates data-centric security (signature verification).

## Technology Stack
- **Frontend:** React, Vite, React Router, Lucide Icons, Custom CSS
- **Backend:** Python, FastAPI, Uvicorn
- **NDN Layer:** Custom Python `NDNService` simulating NFD (Named Data Networking Forwarding Daemon)

## How to Run the Backend
From the `backend` folder in PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn api:app --reload --port 8000
```

The React frontend is not included in this starter bundle. Once available, run it from its `frontend` folder with `npm install` and `npm run dev`, then open http://localhost:5173.
